import "../scss/index.scss"
require('./header.js');
require('./home/home-represent.js');
require('./home/home-popup.js');
require('./home/home-video-popup.js');
require('./home/home-gear1.js');
require('./home/home-gear2.js');
require('./home/home-gear3.js');
require('./home/home-gear4.js');
require('./home/home-gear5.js');
require('./home/home-gear6.js');
